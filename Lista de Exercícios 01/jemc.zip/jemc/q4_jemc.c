#include <stdio.h>
 
int main() {
    int A , B;
    scanf("%d", &A);
    scanf("%d", &B);
    printf("PROD = %d\n", A*B);
    return 0;
}